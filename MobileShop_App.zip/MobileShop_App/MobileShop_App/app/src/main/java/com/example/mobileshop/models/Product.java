package com.example.mobileshop.models;

public class Product {
    private String title;
    private String desription;
    private int thumbnail;
    private String studio;
    private String rating;
    private String streamingLink;
    private int coverPhoto;

    public Product(String title, int thumbnail, int coverPhoto) {
        this.title = title;
        this.thumbnail = thumbnail;
        this.coverPhoto = coverPhoto;
    }

    public Product(String title, String desription, int thumbnail, String studio, String rating, String streamingLink) {
        this.title = title;
        this.desription = desription;
        this.thumbnail = thumbnail;
        this.studio = studio;
        this.rating = rating;
        this.streamingLink = streamingLink;
    }

    public Product(String title, int thumbnail) {
        this.title = title;
        this.thumbnail = thumbnail;
    }
    public void setCoverPhoto(int coverPhoto) {
        this.coverPhoto = coverPhoto;
    }

    public int getCoverPhoto() {
        return coverPhoto;
    }
    public String getTitle() {
        return title;
    }

    public String getDesription() {
        return desription;
    }

    public int getThumbnail() {
        return thumbnail;
    }

    public String getStudio() {
        return studio;
    }

    public String getRating() {
        return rating;
    }

    public String getStreamingLink() {
        return streamingLink;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDesription(String desription) {
        this.desription = desription;
    }

    public void setThumbnail(int thumbnail) {
        this.thumbnail = thumbnail;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public void setStreamingLink(String streamingLink) {
        this.streamingLink = streamingLink;
    }
}
