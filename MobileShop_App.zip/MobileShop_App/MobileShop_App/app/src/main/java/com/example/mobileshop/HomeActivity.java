package com.example.mobileshop;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;


import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.mobileshop.Adapter.ProductAdapter;
import com.example.mobileshop.Adapter.ProductItemClickListener;
import com.example.mobileshop.Adapter.SliderPagerAdapter;
import com.example.mobileshop.models.Product;
import com.example.mobileshop.models.Slide;
import com.example.mobileshop.ui.ProductDetailActivity;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class HomeActivity extends AppCompatActivity implements ProductItemClickListener {

    private List<Slide> listSides;
    private ViewPager sliderpager;
    private TabLayout indicator;
    private RecyclerView ProductRV;
    private DrawerLayout drawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        sliderpager = findViewById(R.id.slider_pager);
        indicator = findViewById(R.id.indicator);
        ProductRV = findViewById(R.id.Rv_movies);
        // prepare a list of Slide
        listSides = new ArrayList<>();
        listSides.add(new Slide(R.drawable.product1, "Slide Title /more text here"));
        listSides.add(new Slide(R.drawable.product2, "Slide Title /more text here"));
        listSides.add(new Slide(R.drawable.product3, "Slide Title /more text here"));
        listSides.add(new Slide(R.drawable.product4, "Slide Title /more text here"));
        listSides.add(new Slide(R.drawable.product5, "Slide Title /more text here"));
        listSides.add(new Slide(R.drawable.product6, "Slide Title /more text here"));

        SliderPagerAdapter adapter = new SliderPagerAdapter(this, listSides);
        sliderpager.setAdapter(adapter);
        // Timer chuyen ListImage
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new HomeActivity.SliderTimer(), 4000, 6000);
        indicator.setupWithViewPager(sliderpager,true);
        //Recycleview Setup
        //init data

        List<Product> listProduct = new ArrayList<>();
        listProduct.add(new Product("Iphone 12", R.drawable.product7));
        listProduct.add(new Product("SamSung Galaxy S20+", R.drawable.product8));
        listProduct.add(new Product("SamSung Galaxy Note 10 Lite", R.drawable.product9));
        listProduct.add(new Product("SamSung Galaxy A51", R.drawable.product10));
        listProduct.add(new Product("Oppo A9 2020", R.drawable.product11));
        listProduct.add(new Product("SamSung Galaxy S20 Ultra", R.drawable.product12));
        listProduct.add(new Product("Vivo Y19", R.drawable.product13));

//        List<Product> listProduct = new ArrayList<>();
//        listProduct.add(new Product("Avengers", R.drawable.avengers));
//        listProduct.add(new Product("GreenLand", R.drawable.greenland));
//        listProduct.add(new Product("Peninsula", R.drawable.peninsula));
//        listProduct.add(new Product("Venom", R.drawable.venom));
//        listProduct.add(new Product("JohnWick1", R.drawable.johnwick_1));
//        listProduct.add(new Product("JohnWick2", R.drawable.johnwick_2));
//        listProduct.add(new Product("JohnWick3", R.drawable.johnwick_3));

        ProductAdapter productAdapter = new ProductAdapter(this, listProduct,  this);
        ProductAdapter productAdapter_Iphone = new ProductAdapter(this, listProduct,  this);
        ProductRV.setAdapter(productAdapter);
        ProductRV.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));



        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public void onProductClick(Product product, ImageView productImageView) {
        //Du lieu tu DetaiMovie
        Intent intent = new Intent(this, ProductDetailActivity.class);
        //Truyen du lieu tu DetailActivity
        intent.putExtra("title",product.getTitle());
        intent.putExtra("imgURL",product.getThumbnail());
        intent.putExtra("imgCover",product.getCoverPhoto());

        //lets create the animation
        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(HomeActivity.this,
                productImageView, "sharedName");
        startActivity(intent,options.toBundle());
        Toast.makeText(this, "item Clicked : + " + product.getTitle(), Toast.LENGTH_SHORT).show();
    }

    //Set Timer
    class SliderTimer extends TimerTask {
        @Override
        public void run() {

            HomeActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (sliderpager.getCurrentItem()<listSides.size()-1){
                        sliderpager.setCurrentItem(sliderpager.getCurrentItem()+1);
                    }
                    else
                        sliderpager.setCurrentItem(0);
                }
            });

        }
    }
}