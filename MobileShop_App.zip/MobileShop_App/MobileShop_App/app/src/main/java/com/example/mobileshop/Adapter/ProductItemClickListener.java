package com.example.mobileshop.Adapter;

import android.widget.ImageView;

import com.example.mobileshop.models.Product;

public interface ProductItemClickListener {
    void onProductClick(Product product, ImageView productImageView);
}
