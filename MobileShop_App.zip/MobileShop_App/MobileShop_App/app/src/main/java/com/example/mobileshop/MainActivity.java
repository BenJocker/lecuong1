package com.example.mobileshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtUserName, edtUserPass;
    Button btnLogin, btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edtUserName = findViewById(R.id.edt_id_logIn);
        edtUserPass = findViewById(R.id.edt_password_logIn);
        btnLogin = findViewById(R.id.btn_login_signIn);
        btnRegister = findViewById(R.id.btn_register_signIn);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = "admin";
                String password = "admin";
                if (edtUserName.getText().toString().equals(username) && edtUserPass.getText().toString().equals(password)){
                    Toast.makeText(getApplicationContext(),R.string.loginsucces, Toast.LENGTH_LONG).show();
                    Intent i = new Intent(MainActivity.this,HomeActivity.class);
                    startActivity(i);
                }
                else {
                    Toast.makeText(getApplicationContext(), R.string.loginerror, Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}