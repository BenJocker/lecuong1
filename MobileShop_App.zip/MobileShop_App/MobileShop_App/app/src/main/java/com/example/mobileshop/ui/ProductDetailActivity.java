package com.example.mobileshop.ui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.mobileshop.R;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView ProductThumbnailImg,ProductCoverImg;
    private TextView tv_title,tv_description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        //ini view
        iniViews();
    }

    private void iniViews() {
        String movieTitle = getIntent().getExtras().getString("title");
        int imageResourceId = getIntent().getExtras().getInt("imgURL");
        int imageCover = getIntent().getExtras().getInt("imgCover");
        ProductThumbnailImg = findViewById(R.id.detail_product_img);
        Glide.with(this).load(imageResourceId).into(ProductThumbnailImg);
        ProductThumbnailImg.setImageResource(imageResourceId);
        ProductCoverImg = findViewById(R.id.detail_product_cover);
        Glide.with(this).load(imageCover).into(ProductCoverImg);
        tv_title = findViewById(R.id.detail_product_title);
        tv_description = findViewById(R.id.detail_product_decs);
    }
}